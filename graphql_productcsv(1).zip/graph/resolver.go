
package graph

import (
    "encoding/csv"
    "fmt"
    "os"
    "strconv"

    "graphql_productcsv/graph/model"
)

var products []*model.Product

type Resolver struct{}

func (r *mutationResolver) AddProductsFromCSV(filePath string) (string, error) {
    file, err := os.Open(filePath)
    if err != nil {
        return "", err
    }
    defer file.Close()

    reader := csv.NewReader(file)
    records, err := reader.ReadAll()
    if err != nil {
        return "", err
    }

    for i, record := range records {
        if i == 0 {
            continue // skip header
        }
        price, _ := strconv.ParseFloat(record[2], 64)
        stock, _ := strconv.Atoi(record[3])
        p := &model.Product{
            ID:          strconv.Itoa(i),
            Name:        record[0],
            Description: record[1],
            Price:       price,
            Stock:       stock,
            Category:    record[4],
        }
        products = append(products, p)
    }

    return fmt.Sprintf("%d products added", len(products)), nil
}

func (r *queryResolver) Products() ([]*model.Product, error) {
    return products, nil
}

func (r *Resolver) Mutation() model.MutationResolver { return &mutationResolver{r} }
func (r *Resolver) Query() model.QueryResolver       { return &queryResolver{r} }

type mutationResolver struct{ *Resolver }
type queryResolver struct{ *Resolver }
