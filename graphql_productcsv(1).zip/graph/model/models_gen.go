
package model

type Product struct {
    ID          string  `json:"id"`
    Name        string  `json:"name"`
    Description string  `json:"description"`
    Price       float64 `json:"price"`
    Stock       int     `json:"stock"`
    Category    string  `json:"category"`
}

type MutationResolver interface {
    AddProductsFromCSV(filePath string) (string, error)
}

type QueryResolver interface {
    Products() ([]*Product, error)
}
