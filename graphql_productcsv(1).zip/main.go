
package main

import (
    "log"
    "net/http"
    "os"

    "github.com/99designs/gqlgen/graphql/handler"
    "github.com/99designs/gqlgen/graphql/playground"
    "github.com/labstack/echo/v4"
    "github.com/labstack/echo/v4/middleware"

    "graphql_productcsv/graph"
    "graphql_productcsv/graph/generated"
)

func main() {
    e := echo.New()
    e.Use(middleware.Logger())
    e.Use(middleware.Recover())

    srv := handler.NewDefaultServer(generated.NewExecutableSchema(generated.Config{Resolvers: &graph.Resolver{}}))
    e.POST("/query", echo.WrapHandler(srv))
    e.GET("/", echo.WrapHandler(playground.Handler("GraphQL playground", "/query")))

    port := os.Getenv("PORT")
    if port == "" {
        port = "8080"
    }
    log.Printf("connect to http://localhost:%s/ for GraphQL playground", port)
    log.Fatal(e.Start(":" + port))
}
